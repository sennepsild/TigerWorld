﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CustomEditor (typeof (MapGenerator))]
public class Map : MonoBehaviour {

	public override void OnInspectorGUI()
    {
        MapGenerator mapGen = (MapGenrator)target;

        if (DrawDefaultInspector())
        {
            if (mapGen.autoUpdate)
            {
                mapGen.GenerateMap();
            }
        }

        if (GUILayout.Button ("Generate"))
        {
            mapGen.GenerateMap();
        }

    }
}
